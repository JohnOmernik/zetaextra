=======================
Authenticating Services
=======================

Module: :mod:`jupyterhub.services.auth`
=======================================

.. automodule:: jupyterhub.services.auth

.. currentmodule:: jupyterhub.services.auth


.. autoclass:: HubAuth
    :members:

.. autoclass:: HubAuthenticated
    :members:

